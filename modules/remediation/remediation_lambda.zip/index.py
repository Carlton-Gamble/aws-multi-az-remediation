import boto3
import os

ec2 = boto3.client('ec2')
QUARANTINE_SG = os.environ['QUARANTINE_SG_ID']

def lambda_handler(event, context):
    print("GuardDuty Finding Event Received:", event)
    try:
        detail = event.get('detail', {})
        resource = detail.get('resource', {})
        instance_details = resource.get('instanceDetails', {})
        instance_id = instance_details.get('instanceId')

        if instance_id:
            print(f"Isolating compromised instance: {instance_id}")
            ec2.modify_instance_attribute(
                InstanceId=instance_id,
                Groups=[QUARANTINE_SG]
            )
            print(f"Successfully attached Quarantine SG {QUARANTINE_SG} to {instance_id}")
        else:
            print("No Instance ID found in GuardDuty event payload.")
    except Exception as e:
        print(f"Error executing remediation: {str(e)}")
        raise e
